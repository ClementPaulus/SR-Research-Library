# Structura Reditus Research Library Engine

**Engine release:** `SR-LIBRARY.v0.1.0-rc1`  
**Specification:** `SR-RESEARCH-LIBRARY-SPEC.v0.1`  
**Status:** Tier-0 organizational protocol candidate  

This repository is the execution engine and source-of-truth registry for the Structura Reditus Research Library.
It is a separate repository-level object. It does **not** modify or replace GCD v2.3.3 or any frozen historical GCD release.

The engine performs five bounded jobs:

```text
IDENTIFY -> REGISTER -> CLASSIFY -> RELATE -> VALIDATE
                                      |
                                      v
                     ACCEPT / RETURN FOR REPAIR / REJECT
                                      |
                                      v
                                   RETRIEVE
```

Library admission is **organizational conformance only**. It is not a scientific truth verdict, canon admission, Tier-0 adoption of the submitted research, Tier-1 promotion, prestige score, or endorsement.

## Governing placement

- Reditus: object.
- Structura Reditus: field.
- Generative Collapse Dynamics (GCD): foundational theory.
- Tier-1 / Tier-0 / Tier-2: authority architecture.
- UMCP / RCFT / ULRC: functional systems.
- Tier-2: translation and expansion authority.
- Research Library: Tier-0 organizational infrastructure for research records.

## Seed identity

The initial author registry contains only the supplied identity fields:

```text
AuthorID: AUTH-0001
Display name: Clement Paulus
ORCID: 0009-0000-6069-8234
Status: active
```

No additional credentials, affiliations, or publication claims are inferred.

## Quick start

Requires Python 3.11+.

```bash
python -m pip install -e .[dev]
python -m sr_library validate --root .
python -m sr_library build-site --root .
python -m sr_library manifest --root . --release SR-LIBRARY.v0.1.0-rc1
pytest
```

Admission of an object:

```bash
python -m sr_library admit path/to/object.yaml --root . --write-receipt
```

## Important pre-release seam

The production `domains` taxonomy is intentionally empty in this release because no complete domain vocabulary has yet been adopted. This prevents the engine from silently inventing a domain ontology. Real research objects therefore cannot receive `ACCEPTED` until their primary domain is introduced through the declared taxonomy-extension path. Tests use synthetic in-memory taxonomies and do not populate the production registry.

See `LIBRARY_SPECIFICATION.md`, `ENGINE_CONTRACT.md`, and `CONTRIBUTING.md` before adding records.
