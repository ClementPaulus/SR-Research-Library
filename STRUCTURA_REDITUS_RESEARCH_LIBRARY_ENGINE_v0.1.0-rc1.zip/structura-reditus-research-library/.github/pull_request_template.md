## Research Library change

- Object(s) affected:
- AuthorID(s):
- SourceID(s):
- RelationID(s):
- Schema version:
- Taxonomy version:
- Admission outcome(s):
- Open seams:

### Checks

- [ ] `python -m sr_library validate --root .`
- [ ] `pytest`
- [ ] No frozen GCD object was modified.
- [ ] No unsupported metadata was invented.
