from __future__ import annotations
from pathlib import Path
import html
from .registry import load_registry


def _page(title: str, body: str) -> str:
    return f"""<!doctype html>
<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>{html.escape(title)}</title>
<style>body{{font-family:system-ui,sans-serif;max-width:980px;margin:3rem auto;padding:0 1rem;line-height:1.55}}code{{background:#eee;padding:.1rem .25rem}}a{{color:#337799}}.meta{{color:#555}}</style></head><body>{body}</body></html>"""


def build_site(root: Path) -> Path:
    reg = load_registry(root)
    out = root / "_site"
    (out / "authors").mkdir(parents=True, exist_ok=True)
    (out / "objects").mkdir(parents=True, exist_ok=True)

    author_links = []
    for aid, a in sorted(reg.authors.items()):
        body = f"<h1>{html.escape(a['display_name'])}</h1><p><code>{aid}</code></p>"
        if a.get('orcid'):
            body += f"<p>ORCID: {html.escape(a['orcid'])}</p>"
        authored = [o for o in reg.objects.values() if any(x.get('author_id') == aid for x in o.get('authors', []))]
        body += f"<p class=\"meta\">Registered authored objects: {len(authored)}</p>"
        (out / "authors" / f"{aid}.html").write_text(_page(a['display_name'], body), encoding="utf-8")
        author_links.append(f'<li><a href="authors/{aid}.html">{html.escape(a["display_name"])}</a> <code>{aid}</code></li>')

    object_links = []
    for oid, o in sorted(reg.objects.items()):
        body = f"<h1>{html.escape(o['title'])}</h1><p><code>{oid}</code></p><p>{html.escape(o.get('main_question',''))}</p>"
        (out / "objects" / f"{oid}.html").write_text(_page(o['title'], body), encoding="utf-8")
        object_links.append(f'<li><a href="objects/{oid}.html">{html.escape(o["title"])}</a> <code>{oid}</code></li>')

    index = "<h1>Structura Reditus Research Library</h1><p>Generated registry view. Admission is organizational conformance only.</p>"
    index += "<h2>Authors</h2><ul>" + "".join(author_links) + "</ul>"
    index += "<h2>Objects</h2><ul>" + ("".join(object_links) or "<li>No research objects registered yet.</li>") + "</ul>"
    (out / "index.html").write_text(_page("Structura Reditus Research Library", index), encoding="utf-8")
    return out
