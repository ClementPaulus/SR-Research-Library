from __future__ import annotations
import argparse
from pathlib import Path
from .io import load_record, dump_json
from .registry import load_registry
from .taxonomy import load_taxonomies
from .admission import evaluate_object, receipt_markdown
from .validation import validate_repository
from .manifest import write_manifest
from .sitegen import build_site


def cmd_validate(args):
    root = Path(args.root).resolve()
    errors = validate_repository(root)
    if errors:
        print("VALIDATION: FAIL")
        for e in errors:
            print(f"- {e}")
        return 1
    print("VALIDATION: PASS")
    return 0


def cmd_admit(args):
    root = Path(args.root).resolve()
    obj_path = Path(args.object).resolve()
    obj = load_record(obj_path)
    receipt = evaluate_object(obj, load_registry(root), load_taxonomies(root))
    print(receipt_markdown(receipt))
    if args.write_receipt:
        folder = {"ACCEPTED":"accepted","RETURNED_FOR_REPAIR":"repair","REJECTED":"rejected"}[receipt["decision"]]
        oid = receipt.get("object_id") or "UNASSIGNED"
        json_path = root / "receipts" / folder / f"{oid}__{receipt['decision']}.json"
        md_path = root / "receipts" / folder / f"{oid}__{receipt['decision']}.md"
        dump_json(json_path, receipt)
        md_path.write_text(receipt_markdown(receipt), encoding="utf-8")
        print(f"Receipt written: {json_path.relative_to(root)}")
    return 0 if receipt["decision"] == "ACCEPTED" else 2


def cmd_manifest(args):
    root = Path(args.root).resolve()
    path = write_manifest(root, args.release)
    print(path)
    return 0


def cmd_site(args):
    root = Path(args.root).resolve()
    out = build_site(root)
    print(out)
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="sr-library")
    sub = p.add_subparsers(dest="command", required=True)

    v = sub.add_parser("validate")
    v.add_argument("--root", default=".")
    v.set_defaults(func=cmd_validate)

    a = sub.add_parser("admit")
    a.add_argument("object")
    a.add_argument("--root", default=".")
    a.add_argument("--write-receipt", action="store_true")
    a.set_defaults(func=cmd_admit)

    m = sub.add_parser("manifest")
    m.add_argument("--root", default=".")
    m.add_argument("--release", required=True)
    m.set_defaults(func=cmd_manifest)

    s = sub.add_parser("build-site")
    s.add_argument("--root", default=".")
    s.set_defaults(func=cmd_site)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    return args.func(args)
