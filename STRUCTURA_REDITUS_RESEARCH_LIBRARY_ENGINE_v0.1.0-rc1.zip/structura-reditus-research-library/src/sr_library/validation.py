from __future__ import annotations
from pathlib import Path
from .registry import load_registry
from .schema_validation import validate_file
from .taxonomy import load_taxonomies
from .io import load_record


def validate_repository(root: Path) -> list[str]:
    errors: list[str] = []
    registry = load_registry(root)
    for dup in registry.duplicate_ids:
        errors.append(f"Duplicate registry identifier: {dup}")

    groups = [
        ("author", root / "registry/authors"),
        ("object", root / "registry/objects"),
        ("source", root / "registry/sources"),
        ("relation", root / "registry/relations"),
    ]
    for kind, directory in groups:
        for path in sorted(directory.glob("*")):
            if path.suffix.lower() not in {".yaml", ".yml", ".json"}:
                continue
            for error in validate_file(root, kind, path):
                errors.append(f"{path.relative_to(root)}: {error}")

    tax = load_taxonomies(root)
    for oid, obj in registry.objects.items():
        for author in obj.get("authors") or []:
            aid = author.get("author_id") if isinstance(author, dict) else None
            if aid and aid not in registry.authors:
                errors.append(f"{oid}: unresolved AuthorID {aid}")
        for sid in obj.get("source_ids") or []:
            if sid not in registry.sources:
                errors.append(f"{oid}: unresolved SourceID {sid}")
        for rid in obj.get("relations") or []:
            if rid not in registry.relations:
                errors.append(f"{oid}: unresolved RelationID {rid}")

    for rid, rel in registry.relations.items():
        rtype = rel.get("relation_type")
        if rtype and rtype not in tax.get("relation_type", set()):
            errors.append(f"{rid}: unknown relation type {rtype}")

    return errors
