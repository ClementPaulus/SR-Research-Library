from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib
from .registry import load_registry
from .taxonomy import taxonomy_metadata
from .io import dump_json


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def build_manifest(root: Path, release: str) -> dict:
    registry = load_registry(root)
    tracked = []
    for prefix in ["schema", "taxonomy", "registry", "src", "docs"]:
        d = root / prefix
        if not d.exists():
            continue
        for p in sorted(d.rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts:
                tracked.append({"path": str(p.relative_to(root)), "sha256": sha256(p)})
    return {
        "release": release,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "specification": "SR-RESEARCH-LIBRARY-SPEC.v0.1",
        "engine_contract": "SR-LIBRARY-ENGINE-CONTRACT.v0.1.0-rc1",
        "counts": {
            "authors": len(registry.authors),
            "objects": len(registry.objects),
            "sources": len(registry.sources),
            "relations": len(registry.relations),
        },
        "taxonomy": taxonomy_metadata(root),
        "open_seams": [
            "Production domain taxonomy is unresolved and intentionally empty.",
            "Publication-state vocabulary remains an operational candidate before v1.0.",
            "Repository license remains undeclared in this pre-release."
        ],
        "files": tracked,
    }


def write_manifest(root: Path, release: str) -> Path:
    out = root / "releases/manifests" / f"{release}.json"
    dump_json(out, build_manifest(root, release))
    return out
