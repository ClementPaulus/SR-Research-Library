from __future__ import annotations
from pathlib import Path
from .io import load_record

FILE_TO_AXIS = {
    "tier2_classes.yaml": "tier2_class",
    "domains.yaml": "domain",
    "focuses.yaml": "focus",
    "evidence_modes.yaml": "evidence_mode",
    "provenance_types.yaml": "provenance",
    "maturity_states.yaml": "maturity",
    "relation_types.yaml": "relation_type",
    "publication_states.yaml": "publication_state",
    "functional_loci.yaml": "functional_locus",
    "missingness_classes.yaml": "missingness_class",
}


def load_taxonomies(root: Path) -> dict[str, set[str]]:
    out: dict[str, set[str]] = {}
    tax_dir = root / "taxonomy"
    for filename, axis in FILE_TO_AXIS.items():
        data = load_record(tax_dir / filename)
        out[axis] = {row["id"] for row in (data.get("values") or [])}
    return out


def taxonomy_metadata(root: Path) -> dict:
    result = {}
    for filename, axis in FILE_TO_AXIS.items():
        data = load_record(root / "taxonomy" / filename)
        result[axis] = {
            "version": data.get("version"),
            "status": data.get("status"),
            "count": len(data.get("values") or []),
            "note": data.get("note", ""),
        }
    return result
