"""Structura Reditus Research Library engine."""

__version__ = "0.1.0rc1"
ENGINE_RELEASE = "SR-LIBRARY.v0.1.0-rc1"
SPECIFICATION = "SR-RESEARCH-LIBRARY-SPEC.v0.1"
