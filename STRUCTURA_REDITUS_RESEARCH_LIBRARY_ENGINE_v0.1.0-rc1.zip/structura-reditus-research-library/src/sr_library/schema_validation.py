from __future__ import annotations
from pathlib import Path
import json
from jsonschema import Draft202012Validator, FormatChecker
from .io import load_record

SCHEMA_FILES = {
    "author": "author.schema.json",
    "object": "object.schema.json",
    "source": "source.schema.json",
    "relation": "relation.schema.json",
    "receipt": "receipt.schema.json",
}


def load_schema(root: Path, kind: str) -> dict:
    return json.loads((root / "schema" / SCHEMA_FILES[kind]).read_text(encoding="utf-8"))


def validate_data(root: Path, kind: str, data: dict) -> list[str]:
    validator = Draft202012Validator(load_schema(root, kind), format_checker=FormatChecker())
    errors = []
    for error in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = ".".join(map(str, error.path)) or "<root>"
        errors.append(f"{loc}: {error.message}")
    return errors


def validate_file(root: Path, kind: str, path: Path) -> list[str]:
    return validate_data(root, kind, load_record(path))
