from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable
from .registry import Registry


@dataclass
class Issue:
    gate: str
    klass: str
    message: str
    repair: str

    def as_dict(self):
        d = asdict(self)
        d["class"] = d.pop("klass")
        return d


GATES = {
    "A": "Identity",
    "B": "Tier placement",
    "C": "Source and provenance",
    "D": "Classification",
    "E": "Boundary and missingness",
    "F": "Relation integrity",
    "G": "Library durability",
}


def _present(obj, dotted: str):
    cur = obj
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    if cur is None:
        return None
    if isinstance(cur, str) and not cur.strip():
        return None
    return cur


def evaluate_object(obj: dict, registry: Registry, tax: dict[str, set[str]]) -> dict:
    gates = {k: "PASS" for k in GATES}
    issues: list[Issue] = []

    def block(gate, klass, message, repair):
        if gates[gate] != "FAIL":
            gates[gate] = "BLOCKED"
        issues.append(Issue(gate, klass, message, repair))

    def fail(gate, klass, message, repair):
        gates[gate] = "FAIL"
        issues.append(Issue(gate, klass, message, repair))

    # Gate A: identity
    oid = obj.get("object_id")
    if not oid:
        block("A", "EVALUABILITY_BLOCKING", "ObjectID is missing.", "Assign a valid SR-OBJ identifier.")
    authors = obj.get("authors") or []
    if not authors:
        block("A", "EVALUABILITY_BLOCKING", "No author identity is declared.", "Declare at least one AuthorID.")
    for author in authors:
        aid = author.get("author_id") if isinstance(author, dict) else None
        if aid and aid not in registry.authors:
            block("A", "SOURCE_BOUNDARY", f"AuthorID {aid} is not registered.", "Register the author before admission.")

    # Gate B: tier placement
    tier = _present(obj, "authority.tier")
    if tier is None:
        block("B", "EVALUABILITY_BLOCKING", "Authority tier is missing.", "Declare authority.tier = 2 for a Tier-2 library object.")
    elif tier != 2:
        fail("B", "CONTRACT_VIOLATING", f"Submitted authority tier is {tier}, not Tier-2.", "Submit under Tier-2 or use a separately authorized non-library path.")
    primary_class = _present(obj, "tier2_class.primary")
    if not primary_class:
        block("B", "EVALUABILITY_BLOCKING", "Primary Tier-2 class is missing.", "Declare exactly one primary Tier-2 class.")
    elif primary_class not in tax.get("tier2_class", set()):
        fail("B", "CONTRACT_VIOLATING", f"Unknown Tier-2 class: {primary_class}.", "Use an adopted Tier-2 class.")

    # Gate C: source and provenance
    provenance = obj.get("provenance")
    if not provenance:
        block("C", "EVALUABILITY_BLOCKING", "Provenance is missing.", "Declare a controlled provenance type.")
    elif provenance not in tax.get("provenance", set()):
        block("C", "REPAIRABLE", f"Unknown provenance type: {provenance}.", "Use or adopt a controlled provenance term.")
    source_ids = obj.get("source_ids") or []
    for sid in source_ids:
        if sid not in registry.sources:
            block("C", "SOURCE_BOUNDARY", f"SourceID {sid} does not resolve.", "Register or correct the source record.")
    if provenance in {"externally-anchored-derivative", "external-source-native", "historical-source-anchored", "dataset-derived", "translation-derived"} and not source_ids:
        block("C", "SOURCE_BOUNDARY", "External or derived provenance is declared without a source record.", "Register at least one governing SourceID.")

    # Gate D: classification
    checks = [
        ("domain.primary", "domain", "primary domain"),
        ("structural_focus.primary", "focus", "primary structural focus"),
        ("evidence_mode.primary", "evidence_mode", "primary evidence mode"),
        ("maturity", "maturity", "maturity state"),
        ("publication_state", "publication_state", "publication state"),
        ("functional_locus.primary", "functional_locus", "functional locus"),
    ]
    for field, axis, label in checks:
        value = _present(obj, field)
        allowed = tax.get(axis, set())
        if not value:
            block("D", "EVALUABILITY_BLOCKING", f"{label.capitalize()} is missing.", f"Declare a controlled {label}.")
        elif not allowed:
            block("D", "UNRESOLVED_SEAM", f"The production {axis} taxonomy has no adopted values.", f"Adopt the necessary {axis} term through the taxonomy-extension path.")
        elif value not in allowed:
            block("D", "REPAIRABLE", f"Unknown {label}: {value}.", f"Use an adopted {label} or propose a taxonomy extension.")
    for field, label in [("object_of_study","object of study"),("main_question","main question")]:
        if not _present(obj, field):
            block("D", "EVALUABILITY_BLOCKING", f"{label.capitalize()} is missing.", f"Declare the {label}.")

    # Gate E: boundary and missingness
    for field, label in [
        ("source_boundary","source boundary"),("authority_boundary","authority boundary"),("scope","scope"),
        ("preserved_meaning","preserved meaning"),("distortion_or_substitution_risk","distortion/substitution risk"),
        ("next_burden","next burden")
    ]:
        if not _present(obj, field):
            block("E", "EVALUABILITY_BLOCKING", f"{label.capitalize()} is missing.", f"Declare the {label}.")
    for item in obj.get("missingness") or []:
        klass = item.get("class") if isinstance(item, dict) else None
        if klass == "CONTRACT_VIOLATING":
            fail("E", klass, item.get("description") or "Contract-violating missingness is declared.", "Resolve the contract violation or submit a materially new object.")
        elif klass in {"EVALUABILITY_BLOCKING", "SOURCE_BOUNDARY", "AUTHORITY_BOUNDARY", "PUBLICATION_BOUNDARY"}:
            block("E", klass, item.get("description") or f"Blocking missingness: {klass}.", "Repair or narrow the affected burden before admission.")

    # Gate F: relation integrity
    for rid in obj.get("relations") or []:
        if rid not in registry.relations:
            block("F", "REPAIRABLE", f"RelationID {rid} does not resolve.", "Register the relation or remove the unsupported reference.")

    # Gate G: durability
    for field, label in [("version","version"),("date","date"),("repair_route","repair route")]:
        if not _present(obj, field):
            block("G", "EVALUABILITY_BLOCKING", f"{label.capitalize()} is missing.", f"Declare the {label}.")

    if "FAIL" in gates.values():
        decision = "REJECTED"
        next_action = "Repair the contract violation if permitted by the receipt; otherwise create a materially new submission."
    elif "BLOCKED" in gates.values():
        decision = "RETURNED_FOR_REPAIR"
        next_action = "Complete the blocking repairs listed in this receipt and resubmit the same object unless a seam or new ObjectID is required."
    else:
        decision = "ACCEPTED"
        next_action = "Register the accepted receipt and include the object in the next eligible library release."

    return {
        "decision": decision,
        "object_id": obj.get("object_id"),
        "title": obj.get("title"),
        "authors": [a.get("author_id") for a in authors if isinstance(a, dict) and a.get("author_id")],
        "version": obj.get("version"),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "gates": gates,
        "issues": [i.as_dict() for i in issues],
        "next_action": next_action,
        "meaning": "Library admission is an organizational conformance decision only. It does not establish scientific truth, endorsement, Tier-0 adoption of the submitted research, or Tier-1 admission."
    }


def receipt_markdown(receipt: dict) -> str:
    lines = [
        "# Structura Reditus Research Library Admission Receipt",
        "",
        f"**Decision:** `{receipt['decision']}`",
        f"**ObjectID:** `{receipt.get('object_id') or 'UNASSIGNED'}`",
        f"**Title:** {receipt.get('title') or 'UNDECLARED'}",
        f"**AuthorID(s):** {', '.join(receipt.get('authors') or []) or 'UNDECLARED'}",
        f"**Version:** {receipt.get('version') or 'UNDECLARED'}",
        f"**Generated:** {receipt['generated_at']}",
        "",
        "## Admission gates",
        "",
    ]
    for gate, status in receipt["gates"].items():
        lines.append(f"- Gate {gate} - {GATES[gate]}: **{status}**")
    lines += ["", "## Issues and repair"]
    if not receipt["issues"]:
        lines += ["", "No blocking issues recorded."]
    else:
        for i, issue in enumerate(receipt["issues"], 1):
            lines += [
                "",
                f"### {i}. Gate {issue['gate']} - {issue['class']}",
                "",
                issue["message"],
                "",
                f"**Repair:** {issue['repair']}",
            ]
    lines += ["", "## Next action", "", receipt["next_action"], "", "## Meaning", "", receipt["meaning"], ""]
    return "\n".join(lines)
