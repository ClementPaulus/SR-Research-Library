from __future__ import annotations
from pathlib import Path
from dataclasses import dataclass, field
from .io import load_record


@dataclass
class Registry:
    authors: dict[str, dict] = field(default_factory=dict)
    objects: dict[str, dict] = field(default_factory=dict)
    sources: dict[str, dict] = field(default_factory=dict)
    relations: dict[str, dict] = field(default_factory=dict)
    duplicate_ids: list[str] = field(default_factory=list)


def _collect(directory: Path, key: str):
    records = {}
    duplicates = []
    if not directory.exists():
        return records, duplicates
    for path in sorted(directory.glob("*")):
        if path.suffix.lower() not in {".yaml", ".yml", ".json"}:
            continue
        data = load_record(path)
        if not isinstance(data, dict):
            continue
        rid = data.get(key)
        if not rid:
            continue
        if rid in records:
            duplicates.append(rid)
        records[rid] = data
    return records, duplicates


def load_registry(root: Path) -> Registry:
    authors, da = _collect(root / "registry/authors", "author_id")
    objects, dob = _collect(root / "registry/objects", "object_id")
    sources, ds = _collect(root / "registry/sources", "source_id")
    relations, dr = _collect(root / "registry/relations", "relation_id")
    return Registry(authors, objects, sources, relations, da + dob + ds + dr)
