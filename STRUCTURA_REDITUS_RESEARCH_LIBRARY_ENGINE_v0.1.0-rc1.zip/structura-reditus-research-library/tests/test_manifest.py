from pathlib import Path
from sr_library.manifest import build_manifest

ROOT = Path(__file__).resolve().parents[1]


def test_manifest_counts_seed_author():
    manifest = build_manifest(ROOT, "SR-LIBRARY.v0.1.0-rc1-test")
    assert manifest["counts"]["authors"] == 1
    assert manifest["counts"]["objects"] == 0
    assert manifest["counts"]["sources"] == 0
    assert manifest["counts"]["relations"] == 0
    assert manifest["open_seams"]
