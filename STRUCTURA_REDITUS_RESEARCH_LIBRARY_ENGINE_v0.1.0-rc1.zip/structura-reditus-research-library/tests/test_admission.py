from sr_library.admission import evaluate_object
from sr_library.registry import Registry


def taxonomies():
    return {
        "tier2_class": {"candidate"},
        "domain": {"synthetic-domain"},
        "focus": {"return"},
        "evidence_mode": {"formal-derivation"},
        "provenance": {"synthetic-test-object"},
        "maturity": {"candidate"},
        "relation_type": {"unresolved_relation"},
        "publication_state": {"unpublished"},
        "functional_locus": {"none-declared"},
        "missingness_class": {"NON_BLOCKING","EVALUABILITY_BLOCKING","CONTRACT_VIOLATING"},
    }


def valid_object():
    return {
        "object_id":"SR-OBJ-999999",
        "title":"Synthetic Admission Fixture",
        "authors":[{"author_id":"AUTH-0001","contribution_role":"synthetic-test"}],
        "authority":{"tier":2},
        "tier2_class":{"primary":"candidate","secondary":[]},
        "functional_locus":{"primary":"none-declared","secondary":[]},
        "source_ids":[],
        "lens":{"primary":"synthetic-test","secondary":[]},
        "domain":{"primary":"synthetic-domain","secondary":[]},
        "object_of_study":"admission engine mechanics",
        "structural_focus":{"primary":"return","secondary":[]},
        "main_question":"Does the structural admission engine derive the expected outcome?",
        "secondary_questions":[],
        "claim_layers":[],
        "evidence_mode":{"primary":"formal-derivation","secondary":[]},
        "provenance":"synthetic-test-object",
        "maturity":"candidate",
        "relations":[],
        "version":"0.0.0-test",
        "date":"2026-09-12",
        "publication_state":"unpublished",
        "source_boundary":"Synthetic fixture only.",
        "authority_boundary":"No research authority is claimed.",
        "scope":"Admission-engine mechanics.",
        "exclusions":["research truth"],
        "preserved_meaning":"Synthetic structural validation only.",
        "missingness":[],
        "distortion_or_substitution_risk":"None beyond synthetic scope.",
        "next_burden":"None; test fixture only.",
        "repair_route":"Repair malformed fields and rerun the test.",
        "notes":"Not a production research object."
    }


def registry():
    return Registry(authors={"AUTH-0001":{"author_id":"AUTH-0001"}})


def test_valid_synthetic_object_accepted():
    receipt = evaluate_object(valid_object(), registry(), taxonomies())
    assert receipt["decision"] == "ACCEPTED"
    assert all(v == "PASS" for v in receipt["gates"].values())


def test_missing_question_returns_for_repair():
    obj = valid_object()
    obj["main_question"] = ""
    receipt = evaluate_object(obj, registry(), taxonomies())
    assert receipt["decision"] == "RETURNED_FOR_REPAIR"
    assert receipt["gates"]["D"] == "BLOCKED"


def test_wrong_tier_rejected():
    obj = valid_object()
    obj["authority"]["tier"] = 1
    receipt = evaluate_object(obj, registry(), taxonomies())
    assert receipt["decision"] == "REJECTED"
    assert receipt["gates"]["B"] == "FAIL"


def test_broken_source_returns_for_repair():
    obj = valid_object()
    obj["provenance"] = "externally-anchored-derivative"
    obj["source_ids"] = ["SRC-123456"]
    tx = taxonomies()
    tx["provenance"].add("externally-anchored-derivative")
    receipt = evaluate_object(obj, registry(), tx)
    assert receipt["decision"] == "RETURNED_FOR_REPAIR"
    assert receipt["gates"]["C"] == "BLOCKED"


def test_contract_violating_missingness_rejected():
    obj = valid_object()
    obj["missingness"] = [{"class":"CONTRACT_VIOLATING","description":"Synthetic contract violation."}]
    receipt = evaluate_object(obj, registry(), taxonomies())
    assert receipt["decision"] == "REJECTED"
    assert receipt["gates"]["E"] == "FAIL"
