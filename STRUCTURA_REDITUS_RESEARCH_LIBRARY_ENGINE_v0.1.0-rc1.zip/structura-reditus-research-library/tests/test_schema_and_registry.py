from pathlib import Path
from sr_library.registry import load_registry
from sr_library.schema_validation import validate_file
from sr_library.validation import validate_repository

ROOT = Path(__file__).resolve().parents[1]


def test_seed_author_validates():
    path = ROOT / "registry/authors/AUTH-0001.yaml"
    assert validate_file(ROOT, "author", path) == []


def test_seed_author_registered_once():
    registry = load_registry(ROOT)
    assert "AUTH-0001" in registry.authors
    assert registry.authors["AUTH-0001"]["display_name"] == "Clement Paulus"
    assert registry.authors["AUTH-0001"]["orcid"] == "0009-0000-6069-8234"
    assert registry.duplicate_ids == []


def test_repository_structural_validation_passes():
    assert validate_repository(ROOT) == []
