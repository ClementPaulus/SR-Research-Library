# Validators

The canonical validator implementation lives in the `sr_library` Python package.

Run:

```bash
python -m sr_library validate --root .
```

Admission evaluation:

```bash
python -m sr_library admit PATH_TO_OBJECT --root . --write-receipt
```

Release manifest:

```bash
python -m sr_library manifest --root . --release SR-LIBRARY.v0.1.0-rc1
```
