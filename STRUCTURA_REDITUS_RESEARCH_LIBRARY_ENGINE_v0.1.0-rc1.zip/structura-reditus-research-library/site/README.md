# Generated Public Library

The public site is a projection of the registry, not a second source of truth.

Generate it with:

```bash
python -m sr_library build-site --root .
```

Output is written to `_site/` and is intentionally not committed by default.
