# Contributing to the Structura Reditus Research Library

The library accepts records, not prestige claims. All authors, including `AUTH-0001`, use the same admission path.

## 1. Register an author

Create `registry/authors/AUTH-xxxx.yaml` using `schema/author.schema.json`.
Use the next available identifier. Supply only verifiable or explicitly declared metadata. Credentials require a verification state.

## 2. Register sources

Before an externally anchored object is admitted, create any missing `SRC-xxxxxx` records in `registry/sources/`.
Preserve original authorship and source-native claims. Do not rewrite an external source as a Structura Reditus claim.

## 3. Prepare a research object

Create `registry/objects/SR-OBJ-xxxxxx.yaml` and include all fields required by `schema/object.schema.json` and `LIBRARY_SPECIFICATION.md`.

Every object needs one primary Tier-2 class, one primary domain, one primary structural focus, one main question, one primary evidence mode, provenance, authority boundary, missingness declaration, next burden, version identity, and publication state.

## 4. Relations

Create `REL-xxxxxx` records only for relations that can be stated without exceeding the available evidence. Structural resemblance alone does not prove support, identity, continuity, reproduction, validation, or causation.

## 5. Validate

```bash
python -m sr_library validate --root .
pytest
```

## 6. Admission

```bash
python -m sr_library admit registry/objects/SR-OBJ-xxxxxx.yaml --root . --write-receipt
```

The engine returns exactly one of:

- `ACCEPTED`
- `RETURNED_FOR_REPAIR`
- `REJECTED`

A non-accepted object receives a receipt describing the blocking structure and return path.

## 7. Taxonomy extensions

Do not invent near-duplicate labels in an object record. Propose new controlled terms using `docs/TAXONOMY_EXTENSION.md` before using them in production records.

## 8. Pull requests

A pull request should state:

- objects added or changed;
- identifiers affected;
- schema/taxonomy version used;
- validator result;
- admission receipt result;
- any unresolved seam.

Do not modify GCD v2.3.3 or a historical GCD object as part of a library contribution.
