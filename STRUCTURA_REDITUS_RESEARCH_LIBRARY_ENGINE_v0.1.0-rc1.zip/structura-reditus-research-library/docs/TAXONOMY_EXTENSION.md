# Controlled Taxonomy Extension

A production record must not invent a new controlled term inline.

Propose:

```text
Term proposed:
Taxonomy:
Definition:
Reason existing term is insufficient:
Nearest existing terms:
Examples:
Ambiguity risk:
Backward-compatibility effect:
Decision:
Version introduced:
```

Until adopted, an unavailable controlled term is typed as a blocking taxonomy gap and the object is returned for repair rather than silently normalized.
