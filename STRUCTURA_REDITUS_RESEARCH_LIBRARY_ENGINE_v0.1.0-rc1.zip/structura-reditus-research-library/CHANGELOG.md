# Changelog

## SR-LIBRARY.v0.1.0-rc1 - 2026-09-12

Initial engine candidate.

- Established independent Research Library repository structure.
- Added author, object, source, relation, and receipt schemas.
- Added controlled Tier-2, focus, evidence, provenance, maturity, relation, publication, functional-locus, and missingness taxonomies.
- Preserved domain taxonomy as an explicit unresolved pre-release seam rather than inventing a complete domain ontology.
- Registered `AUTH-0001` using supplied identity fields only.
- Implemented seven admission gates and three outcomes.
- Implemented repository validation, receipt generation, release manifests, and basic static-site generation.
- Added tests and CI workflow.
