# Taxonomy Extension Proposal

Term proposed:
Taxonomy:
Definition:
Reason existing term is insufficient:
Nearest existing terms:
Examples:
Ambiguity risk:
Backward-compatibility effect:
Decision: pending
Version introduced: pending
