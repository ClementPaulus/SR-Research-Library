# Handoff for submission 5ced692d-5d3a-4d14-9b3f-c552f3a1cff0 revision 1

Object identity: SR-OBJ-000032
Purpose: reconstruct the exact evaluated (or explicitly pending) record and its evidence.
State: ACCEPTED
Exact remaining action: None: the record is registered.
Package scope: public-safe export (private files, login data and credentials excluded)

## Reconstruction
1. Check out the research repository at the `registry_base` commit in execution-manifest.json.
2. Install the pinned engine dependencies: `pip install -r requirements-dev.txt` at that commit (lock hash in execution-manifest.json → dependency_lock).
3. Verify `sha256sum -c SHA256SUMS` and that submission.json hashes to `submission_hash`.
4. Reproduce: `python -m validators.admit submission.json` and compare the seven gate results with receipt.json (timestamps may differ; gate results and decision must not).

Library admission confirms that the record meets the organizational requirements. It does not certify the scientific claims.
